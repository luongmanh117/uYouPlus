#import <YouTubeHeader/YTCommonColorPalette.h>
#import <YouTubeHeader/ASCollectionView.h>
#import <YouTubeHeader/_ASDisplayView.h>
#import "uYouPlus.h"

// @interface YCHLiveChatView : UIView
// @end

@interface YTFullscreenEngagementOverlayView : UIView
@end

@interface YTRelatedVideosView : UIView
@end

// @interface ELMView : UIView
// @end

@interface ASWAppSwitcherCollectionViewCell : UIView
@end

@interface ASScrollView : UIView
@end

@interface UIKeyboardLayoutStar : UIView
@end

@interface UIKeyboardDockView : UIView
@end

// @interface YTCommentDetailHeaderCell : UIView
// @end

@interface SponsorBlockSettingsController : UITableViewController
@end

@interface SponsorBlockViewController : UIViewController
@end

@interface UICandidateViewController : UIViewController
@end

@interface UIPredictionViewController : UIViewController
@end

@interface TUIEmojiSearchView : UIView
@end

@interface FRPreferences : UITableViewController
@end

@interface FRPSelectListTable : UITableViewController
@end

@interface settingsReorderTable : UIViewController
@property(nonatomic, strong) UITableView *tableView;
@end